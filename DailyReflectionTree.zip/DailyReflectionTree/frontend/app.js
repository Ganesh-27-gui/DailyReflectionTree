let tree = {};
let current = localStorage.getItem("current")||"start";

async function loadTree(){
  const res = await fetch("http://localhost:5000/tree");
  tree = await res.json();
  showQuestion();
}

loadTree();

function showQuestion(){

  const node = tree[current];

  if(!node){
    console.error("Node not found:", current);
    return;
  }

  if(node.result){
    document.getElementById("app").innerHTML =
      `<h3>${node.result}</h3>
       <br>
       <button onclick="restart()">Restart</button>`;
    return;
  }

  let html = `<h3>${node.question}</h3>`;

  node.options.forEach((option, index) => {
    html += `
      <button onclick="next(${index})">
        ${option.text}
      </button><br><br>
    `;
  });

  document.getElementById("app").innerHTML = html;
}

function next(index){

  const option = tree[current].options[index];

  fetch("http://localhost:5000/save", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      answer: option.text,
      time: new Date()
    })
  });

  current = option.next;
  localStorage.setItem("current",current);
  showQuestion();
}

function restart(){
  current = "start";
  localStorage.setItem("current",current);
  showQuestion();
}