const express = require("express");
const cors = require("cors");
const fs = require("fs");

const app = express();

app.use(cors());
app.use(express.json());

// Load JSON Tree
app.get("/tree", (req, res) => {

fs.readFile("../frontend/tree.json", "utf8", (err, data) => {

if (err) {
return res.status(500).send("Error reading file");
}

res.json(JSON.parse(data));

});

});

// Save Reflection
app.post("/save", (req, res) => {

const reflection = req.body;

fs.readFile("./reflections.json", "utf8", (err, data) => {

let reflections = [];

try {
reflections = JSON.parse(data || "[]");
} catch {
reflections = [];
}

reflections.push(reflection);

fs.writeFile(
"./reflections.json",
JSON.stringify(reflections, null, 2),
(err) => {

if(err){
console.log(err);
return res.status(500).send("Error saving");
}

res.send("Saved");

});

});

});

app.listen(5000, () => {
console.log("Server running on port 5000");
});