# Daily Reflection Tree

## Overview

Daily Reflection Tree is a deterministic decision-tree based reflection tool.  
It helps employees reflect on their day using structured questions.

This project is built as part of the DT CultureTech Assignment.

---

## Features

- Deterministic Decision Tree
- No AI Runtime
- Multiple Question Branching
- Final Reflection Output
- Clean UI

---

## Psychological Axes

The reflection is based on:

1. Locus (Victim vs Victor)
2. Orientation (Contribution vs Entitlement)
3. Radius (Self vs Team vs Organization)

---

## Tech Stack

- HTML
- CSS
- JavaScript
- JSON

---

## Project Structure
